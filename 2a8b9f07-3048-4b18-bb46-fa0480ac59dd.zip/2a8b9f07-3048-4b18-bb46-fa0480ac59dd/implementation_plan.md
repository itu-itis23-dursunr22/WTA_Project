# Saldırı Odaklı Silah-Hedef Atama (Attack WTA) Modeli

Makaledeki savunma odaklı (multi-to-multi interception) modelini, verdiğiniz parametreler doğrultusunda bir saldırı senaryosuna uyarlıyoruz.

## 1. Karar Değişkenleri (Decision Variables)
Problemi modellemek için füzeler ve decoy'lar (yanıltıcılar) için iki ayrı atama matrisi tanımlıyoruz:
- $X_{i,j} \in \{0, 1\}$ : $i$. füzenin $j$. hedefe atanma durumu (1: Atandı, 0: Atanmadı).
- $Y_{k,j} \in \{0, 1\}$ : $k$. decoy'un $j$. hedefe atanma durumu (1: Atandı, 0: Atanmadı).
  - *Not: $j$. hedefe giden toplam decoy sayısı $N_j = \sum_k Y_{k,j}$ olacaktır.*

## 2. Parametreler (Parameters)
- $m$: Toplam füze sayısı
- $d$: Toplam decoy sayısı
- $n$: Toplam hedef sayısı
- $V_j$: $j$. hedefin önem/değer puanı
- $C_{i,j} \in \{0, 1\}$: Füze-Hedef uyumluluk matrisi (1: Uyumlu, 0: Değil)
- $T_{go, i, j}$: $i$. füzenin $j$. hedefe varış süresi (Kinematik olarak hesaplanır)
- $\epsilon$: Aynı hedefe atılan füzeler arasındaki maksimum varış süresi farkı (Salvo Attack)
- $c_i$: $i$. füzenin operasyonel maliyeti
- $c_{d,k}$: $k$. decoy'un operasyonel maliyeti
- $B$: Toplam operasyonel bütçe
- $P_{hit, i, j}$: $i$. füzenin $j$. hedefi vurma olasılığı (Makaledeki kinematik olasılık veya girdi olarak verilir)
- $P_{kill, i, j}$: $i$. füzesi vurduğunda $j$. hedefini yok etme olasılığı
- $P_{min, j}, P_{max, j}$: $j$. hedef için minimum ve maksimum penetrasyon (hava savunmasını aşma) olasılıkları
- $\lambda$: Decoy doygunluk (saturation) katsayısı ($N_j$ arttıkça etkinin artması için formülde $-\lambda$ kullanılmıştır)

## 3. Olasılık Fonksiyonları
Hedefe giden decoy sayısı $N_j$'ye bağlı olarak penetrasyon olasılığı:
$$P_{pen, j} = P_{min, j} + (P_{max, j} - P_{min, j}) \times (1 - e^{-\lambda N_j})$$

Bir hedefe atanmış bir füzenin hedefi yok etme başarısı:
$$P^{succ}_{i,j} = P_{pen, j} \times P_{hit, i, j} \times P_{kill, i, j}$$

## 4. Amaç Fonksiyonu (Objective Function)
Amacımız, düşmanın hayatta kalma ihtimalini minimize etmek, yani beklenen hayatta kalma değerini (Expected Survival Value) en aza indirmektir:

$$ \min J = \sum_{j=1}^{n} V_j \prod_{i=1}^{m} \left( 1 - P^{succ}_{i,j} \cdot X_{i,j} \right) $$

*(ABC, PSO, GA gibi algoritmalar genellikle minimizasyon yapar, bu amaç fonksiyonu bu sezgisel algoritmalarla doğrudan kullanılabilir.)*

## 5. Kısıtlar (Constraints)
Kısıtları sezgisel algoritmalar (ABC/PSO) içerisinde **Ceza Fonksiyonu (Penalty Function)** yöntemiyle amaç fonksiyonuna ekleyeceğiz.

1. **Uyumluluk Kısıtı:** Bir füze sadece uyumlu olduğu hedefe atılabilir.
   $$X_{i,j} \le C_{i,j} \quad \forall i, j$$
2. **Atama Limiti:** Bir füze veya decoy en fazla 1 hedefe atılabilir. (Kullanılmamak da bir seçenektir).
   $$\sum_{j=1}^{n} X_{i,j} \le 1 \quad \forall i$$
   $$\sum_{j=1}^{n} Y_{k,j} \le 1 \quad \forall k$$
3. **Maliyet Kısıtı:** Toplam maliyet bütçeyi aşamaz.
   $$\sum_{i=1}^{m} \sum_{j=1}^{n} c_i \cdot X_{i,j} + \sum_{k=1}^{d} \sum_{j=1}^{n} c_{d,k} \cdot Y_{k,j} \le B$$
4. **Decoy Kısıtı:** Füze atılmayan hedefe decoy atılamaz. Eğer hedefe atılan füze sayısı 0 ise, $N_j = 0$ olmalıdır.
   $$N_j \le M \cdot \sum_{i=1}^{m} X_{i,j} \quad \forall j \text{ (M yeterince büyük bir sayı)}$$
5. **Eşzamanlı Vuruş (Tgo / Salvo) Kısıtı:** Hedef $j$'ye atılan füzeler var ise, maksimum ve minimum Tgo arasındaki fark $\epsilon$'dan küçük olmalıdır.
   $$\max_{i \in \{i | X_{i,j}=1\}} (T_{go, i, j}) - \min_{i \in \{i | X_{i,j}=1\}} (T_{go, i, j}) \le \epsilon \quad \forall j$$

---
## User Review Required
Lütfen matematiksel formülasyonu kontrol edin. Eklemek veya değiştirmek istediğiniz bir yer var mı? (Özellikle e üzeri eksi lambda kısmı matematiksel yakınsama için düzeltildi).

## Open Questions
1. Modeli MATLAB'da ABC/PSO gibi sezgisel algoritmalara uygularken genetik şifreleme (encoding) yapısı değişecek. Makaledeki gibi her elemanın bir hedefe atanması zorunluluğu kalktığı için, vektörlere `0` değerini (hiçbir hedefe atanmadı) dahil etmemiz gerekecek. 
2. Halihazırda elinizde bulunan MATLAB kodlarındaki (amaç fonksiyonunu hesaplayan ve penalty hesabı yapan kısım ile algoritmanın ana döngüsünün olduğu dosyalar) kısımları paylaşırsanız, kodunuzun mimarisine tam uygun şekilde bu yeni modeli entegre etmeye başlayabiliriz.
