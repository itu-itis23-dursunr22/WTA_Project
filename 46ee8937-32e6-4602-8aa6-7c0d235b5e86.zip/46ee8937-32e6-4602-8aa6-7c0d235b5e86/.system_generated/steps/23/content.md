Title: Live Content

Description: Fetched live

Source: https://ieeexplore.ieee.org/document/8666060

---

<!DOCTYPE html>
















































<APM_DO_NOT_TOUCH>

<script type="text/javascript">
(function(){
window.gOqo=!!window.gOqo;try{(function(){(function ol(){var O=!1;function Z(O){for(var Z=0;O--;)Z+=_(document.documentElement,null);return Z}function _(O,Z){var J="vi";Z=Z||new I;return zl(O,function(O){O.setAttribute("data-"+J,Z.I$());return _(O,Z)},null)}function I(){this.sI=1;this.Ii=0;this.SZ=this.sI;this.ZS=null;this.I$=function(){this.ZS=this.Ii+this.SZ;if(!isFinite(this.ZS))return this.reset(),this.I$();this.Ii=this.SZ;this.SZ=this.ZS;this.ZS=null;return this.SZ};this.reset=function(){this.sI++;this.Ii=0;this.SZ=this.sI}}var J=!1;
function ll(O,Z){var _=document.createElement(O);Z=Z||document.body;Z.appendChild(_);_&&_.style&&(_.style.display="none")}function Ll(Z,_){_=_||Z;var I="|";function ll(O){O=O.split(I);var Z=[];for(var _=0;_<O.length;++_){var J="",Ll=O[_].split(",");for(var Zl=0;Zl<Ll.length;++Zl)J+=Ll[Zl][Zl];Z.push(J)}return Z}var Ll=0,zl="datalist,details,embed,figure,hrimg,strong,article,formaddress|audio,blockquote,area,source,input|canvas,form,link,tbase,option,details,article";zl.split(I);zl=ll(zl);zl=new RegExp(zl.join(I),
"g");while(zl.exec(Z))zl=new RegExp((""+new Date)[8],"g"),O&&(J=!0),++Ll;return _(Ll&&1)}function zl(O,Z,_){(_=_||J)&&ll("div",O);O=O.children;var I=0;for(var Ll in O){_=O[Ll];try{_ instanceof HTMLElement&&(Z(_),++I)}catch(zl){}}return I}Ll(ol,Z)})();var Ol=88;
try{var sl,_l,jl=L(456)?1:0,lL=L(406)?1:0,OL=L(516)?1:0,zL=L(316)?1:0,_L=L(298)?1:0,IL=L(323)?1:0,jL=L(714)?1:0,lo=L(268)?1:0;for(var Lo=(L(614),0);Lo<_l;++Lo)jl+=L(340)?2:1,lL+=(L(731),2),OL+=L(753)?2:1,zL+=L(34)?2:1,_L+=(L(408),2),IL+=L(808)?2:1,jL+=L(801)?2:1,lo+=L(106)?3:2;sl=jl+lL+OL+zL+_L+IL+jL+lo;window.sZ===sl&&(window.sZ=++sl)}catch(Oo){window.sZ=sl}var zo=!0;function z(l,O){l+=O;return l.toString(36)}
function so(l){var O=99;!l||document[s(O,217,204,214,204,197,204,207,204,215,220,182,215,196,215,200)]&&document[S(O,217,204,214,204,197,204,207,204,215,220,182,215,196,215,200)]!==z(68616527567,O)||(zo=!1);return zo}function S(l){var O=arguments.length,Z=[];for(var _=1;_<O;++_)Z.push(arguments[_]-l);return String.fromCharCode.apply(String,Z)}function _o(){}so(window[_o[S(Ol,198,185,197,189)]]===_o);so(typeof ie9rgb4!==S(Ol,190,205,198,187,204,193,199,198));
so(RegExp("\x3c")[z(1372117,Ol)](function(){return"\x3c"})&!RegExp(z(42801,Ol))[z(1372117,Ol)](function(){return"'x3'+'d';"}));
var io=window[S(Ol,185,204,204,185,187,192,157,206,189,198,204)]||RegExp(S(Ol,197,199,186,193,212,185,198,188,202,199,193,188),z(-70,Ol))[S(Ol,204,189,203,204)](window["\x6e\x61vi\x67a\x74\x6f\x72"]["\x75\x73e\x72A\x67\x65\x6et"]),Jo=+new Date+(L(386)?6E5:671170),lO,LO,zO,ZO=window[S(Ol,203,189,204,172,193,197,189,199,205,204)],sO=io?L(980)?42156:3E4:L(822)?6E3:4919;
document[s(Ol,185,188,188,157,206,189,198,204,164,193,203,204,189,198,189,202)]&&document[S(Ol,185,188,188,157,206,189,198,204,164,193,203,204,189,198,189,202)](S(Ol,206,193,203,193,186,193,196,193,204,209,187,192,185,198,191,189),function(l){var O=86;document[S(O,204,191,201,191,184,191,194,191,202,207,169,202,183,202,187)]&&(document[S(O,204,191,201,191,184,191,194,191,202,207,169,202,183,202,187)]===z(1058781897,O)&&l[s(O,191,201,170,200,203,201,202,187,186)]?zO=!0:document[s(O,204,191,201,191,
184,191,194,191,202,207,169,202,183,202,187)]===z(68616527580,O)&&(lO=+new Date,zO=!1,_O()))});function s(l){var O=arguments.length,Z=[],_=1;while(_<O)Z[_-1]=arguments[_++]-l;return String.fromCharCode.apply(String,Z)}function _O(){if(!document[s(49,162,166,150,163,170,132,150,157,150,148,165,160,163)])return!0;var l=+new Date;if(l>Jo&&(L(568)?6E5:301284)>l-lO)return so(!1);var O=so(LO&&!zO&&lO+sO<l);lO=l;LO||(LO=!0,ZO(function(){LO=!1},L(306)?1:0));return O}_O();
var iO=[L(251)?17795081:11873029,L(275)?27611931586:2147483647,L(834)?1558153217:1603702353];function IO(l){var O=44;l=typeof l===z(1743045632,O)?l:l[s(O,160,155,127,160,158,149,154,147)](L(944)?36:32);var Z=window[l];if(!Z||!Z[S(O,160,155,127,160,158,149,154,147)])return;var _=""+Z;window[l]=function(l,O){LO=!1;return Z(l,O)};window[l][S(O,160,155,127,160,158,149,154,147)]=function(){return _}}for(var JO=(L(371),0);JO<iO[s(Ol,196,189,198,191,204,192)];++JO)IO(iO[JO]);
so(!1!==window[s(Ol,191,167,201,199)]);window.iz=window.iz||{};window.iz.oI="083a15325a1940002d47e6fe63947e22a45f52e27d5fd5de5ee1707a9d83af44f010b3922bb5d3f276e600edfa6688a82a723fd13557f841c3f53dfeaee12fbf7f5797d63ada4366";function Lz(l){var O=+new Date,Z;!document[s(79,192,196,180,193,200,162,180,187,180,178,195,190,193,144,187,187)]||O>Jo&&(L(840)?6E5:666748)>O-lO?Z=so(!1):(Z=so(LO&&!zO&&lO+sO<O),lO=O,LO||(LO=!0,ZO(function(){LO=!1},L(982)?0:1)));return!(arguments[l]^Z)}function L(l){return 953>l}(function oz(O){return O?0:oz(O)*oz(O)})(!0);})();}catch(x){}finally{ie9rgb4=void(0);};function ie9rgb4(a,b){return a>>b>>0};

})();

</script>
</APM_DO_NOT_TOUCH>

<script type="text/javascript" src="/TSPD/0807dc117eab200031f98b4f46feebd7b1b514654c90530b32a95ee438e27009506977c1c1c6d1ee?type=9"></script>
<script type="text/javascript">

var home = {	
			metadata:{
				searchCount: '7,310,939',
				logoRelPath: '/xploreAssets/images/customer_logos/',
				thirdParthAuth: false,
				currentPage:  'document',
				xploreVirtual:'https://xplorestaging.ieee.org',
				isWebAccount: false,
				isProvisioned: false,				
				globalNotification:{},
				cart: {
						count: 0
				}
			}						
		};
		





		
</script>

<html lang="en-US">
	<head>
		<link rel="icon" type="image/x-icon" href="/assets/img/favicon.ico">
	    <meta name="google-site-verification" content="qibYCgIKpiVF_VVjPYutgStwKn-0-KBB6Gw4Fc57FZg" />
					
						
				
					
			 
			
				
		<meta name="Description" id="meta-description" content="Transient cell current caused by the trapping/detrapping of grain boundary traps in the polycrystalline silicon (poly-Si) channel of a 3-D NAND cell string is c">
		
		<link rel="canonical" href="https://xplorestaging.ieee.org/document/8666060" /> 
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
		<!-- Disable "click" touch event 300ms delay for Chrome/Firefox on Android -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Grain Boundary Trap-Induced Current Transient in a 3-D NAND Flash Cell String | IEEE Journals &amp; Magazine | IEEE Xplore</title>
		
    <meta name="bingbot" content="nocache"> 
	
	    
		
  		
  		    <meta property="og:image" content="https://xplorestaging.ieee.org/assets/img/ieee_logo_smedia_200X200.png" />
			<meta name="twitter:card" content="summary" />			
 			<meta property="twitter:image" content="https://xplorestaging.ieee.org/assets/img/ieee_logo_smedia_200X200.png" />			
  		
					
		
			<meta property="twitter:title" content="Grain Boundary Trap-Induced Current Transient in a 3-D NAND Flash Cell String" />
			<meta property="og:title" content="Grain Boundary Trap-Induced Current Transient in a 3-D NAND Flash Cell String" />
		
		
			<meta property="twitter:description" content="Transient cell current caused by the trapping/detrapping of grain boundary traps in the polycrystalline silicon (poly-Si) channel of a 3-D NAND cell string is comprehensively studied in this paper. This transient has a time constant of 10 μs or longer and is strongly dependent on the bias history. It is also affected by the trap distribution as revealed by TCAD simulations. Sensing offset between program verify and read results in “pseudo” charge loss/gain that reduces the sensing margin. The posttreatment of the poly-Si channel is suggested to mitigate this effect." />
			<meta property="og:description" content="Transient cell current caused by the trapping/detrapping of grain boundary traps in the polycrystalline silicon (poly-Si) channel of a 3-D NAND cell string is comprehensively studied in this paper. This transient has a time constant of 10 μs or longer and is strongly dependent on the bias history. It is also affected by the trap distribution as revealed by TCAD simulations. Sensing offset between program verify and read results in “pseudo” charge loss/gain that reduces the sensing margin. The posttreatment of the poly-Si channel is suggested to mitigate this effect." />
							 	
	
	

		






	<script type="text/javascript" src="/ruxitagentjs_ICANVfgqrux_10339260603164134.js" data-dtconfig="app=ea7c4b59f27d43eb|cuc=mlbqoquq|owasp=1|mel=100000|featureHash=ICANVfgqrux|dpvc=1|lastModification=1781720952144|tp=500,50,0|rdnt=1|uxrgce=1|srbbv=2|agentUri=/ruxitagentjs_ICANVfgqrux_10339260603164134.js|reportUrl=/rb_bf59084mku|rid=RID_496877434|rpid=419444204|domain=ieee.org"></script><script type="text/javascript" src="https://config.datas3ntinel.com/tag/js-web-sdk/latest/init.min.js"></script>
	<script type="text/javascript" src="https://assets.adobedtm.com/e5c8ba88cef8/7fd951921a72/launch-2ea1791fadf8-development.min.js" async></script>


		





	
	
		<script src="https://cmp.osano.com/AzyzptTmRlqVd2LRf/31fb9a9d-87e1-48ed-a2c3-52f3e51839f1/osano.js"></script>
		<link rel="stylesheet" href="https://xploreqa.ieee.org/assets/css/osano-cookie-consent-xplore.css" type="text/css"/>
	

		





 


	
	
	
	
	
	
	
	
	
	
	
	
	

	

	

	
	
	

	

	

	
	
	
	
	
	

	

	
	
	
	
	
	
	
	
	
	
	
		
	

	

	

	
		
	
		
		
			
			
	


<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge">






<g:compress>
	<link rel="stylesheet" href="/assets/css/simplePassMeter.min.css?cv=20240710_830000" />
	<link rel="stylesheet" type="text/css" media="screen, print" href="/assets/dist/ng-new/styles.css?cv=20240710_830000"/>
	<link rel="stylesheet" type="text/css" media="screen, print" href="/assets/dist/ng-new/customStyles.css?cv=20240710_830000"/>
	<link rel="stylesheet" href="/assets/vendor/swiper/dist/idangerous.swiper.css?cv=20240710_830000">
	<link rel="stylesheet" type="text/css" media="screen, print" href="/assets/css/jquery-ui-1.8.19.custom.css?cv=20240710_830000"/>
</g:compress>




		

	<script type='text/javascript'>
		var googletag = googletag || {};
		googletag.cmd = googletag.cmd || [];
		(function() {
		var gads = document.createElement('script');
		gads.async = true;
		gads.type = 'text/javascript';
		var useSSL = 'https:' == document.location.protocol;
		gads.src = (useSSL ? 'https:' : 'http:') + 
		'//securepubads.g.doubleclick.net/tag/js/gpt.js';
		var node = document.getElementsByTagName('script')[0];
		node.parentNode.insertBefore(gads, node);
		})();
	</script>

		<script type="text/javascript" src="/assets/vendor/jquery/jquery-3.5.1.min.js?cv=20240710_830000" charset="utf-8"></script>
		
	</head>
	<body class="body-resp">

		<div id="global-notification" class="row stats-global-notification">
			<div class="hide u-hide-important col Notification Notification--global Notification--fixed">
				<a href class="Notification-close js-close" aria-label="close message button"><i class="fa fa-close"></i></a>
				<div class="Notification-header"></div>
				<div class="Notification-text"></div>
			</div>
		</div>

		<div id="LayoutWrapper">
				<div class="row">
					<div class="col">
						







<div class="Header" id="xplore-header" data-service="false" data-inst="false" data-web="false" style="display:none"></div>



						<div id="global-alert-message"></div>
						





<div style="width: 0px; height: 0px"><a href="/rest/api/hpdata" tabindex="-1" aria-hidden="true"></a></div>
<meta name="cToken" content="eyJhbGciOiJIUzUxMiIsInppcCI6IkRFRiJ9.eNqqVkosKFCyUoooyMkvSlXSUcosLgZyK2Dc1AqgrKG5hZGxpYmBkRFQPrEEJmBsaGRUCwAAAP__.8WVUnt8vPqxwxRU7F5Azwet-qzqsoTjiYGPxhutt7M5aSTMHeiBe8N3gkh7pm3f1QD4ssifTNIrnOXAanYNSEg">

<script type="text/javascript">
	
	
	
	document.write('<base href="/document/" />');
	
	
</script>

<!-- XPL-21560-Added as part of Universal CASA-Dev -->
<script type="text/javascript" src="https://scholar.google.com/scholar_js/casa.js" async></script>

<script type="text/javascript" src="https://app.cadmoremedia.com/Scripts/Embed.js"></script>
<!--- This is a picture popup embed for mobilew view.  -->
<script type="text/javascript" src="https://app.cadmoremedia.com/Scripts/PicturePop.js"></script>







<script type="text/javascript">
var body_rightsLink ="", body_publisher = "";
var recordId = "";


var AUTHOR_PROFILE = 'ON';
if (AUTHOR_PROFILE.toUpperCase() == "OFF"){
	var AUTHOR_PROFILE_ENABLED = false;
}else{
	var AUTHOR_PROFILE_ENABLED = true;
}

var xplGlobal = {
	document: {
		disqus:{
			remote_auth_s3 : '',
			public_api_key:'1lxKgMbpNIbQvfk2tqLcWeSVloE8rgIY2CV1tCu3Vp641oL4eEITYBbkViJJGNYY',
			short_name:'ieeexplore',
			client_url:'https://xplorestaging.ieee.org',
			sso_enabled:'{$sessionProfile.provisioned}'
		},

		fullTextAccess: false,
		isISAuthorized: false,
		isAccessFromInstitution: false
		
	}
};
	
	xplGlobal.document.metadata={"userInfo":{"institute":false,"member":false,"individual":false,"guest":false,"subscribedContent":false,"fileCabinetContent":false,"fileCabinetUser":false,"dtrDeleteCookieOnLogout":false,"institutionalFileCabinetUser":false,"dtrCookieExpirationDays":0,"showPatentCitations":true,"showGet802Link":false,"showOpenUrlLink":false,"tracked":false,"institutionUserId":0,"delegatedAdmin":false,"desktop":false,"isInstitutionDashboardEnabled":false,"isInstitutionProfileEnabled":false,"isRoamingEnabled":false,"isDelegatedAdmin":false,"isMdl":false,"isCwg":false,"isReadAndPublish":false,"isIel":false,"isAcademic":false},"authors":[{"name":"Wei-Liang Lin","affiliation":["Department of Electronics Engineering and Institute of Electronics, National Chiao Tung University, Hsinchu, Taiwan"],"firstName":"Wei-Liang","lastName":"Lin","orcid":"0000-0002-8952-4585","id":"38183765300"},{"name":"Wen-Jer Tsai","affiliation":["Macronix International Company, Ltd., Hsinchu, Taiwan"],"firstName":"Wen-Jer","lastName":"Tsai","orcid":"0000-0002-9500-1959","id":"37270013700"},{"name":"C. C. Cheng","affiliation":["Macronix International Company, Ltd., Hsinchu, Taiwan"],"firstName":"C. C.","lastName":"Cheng","id":"37855372700"},{"name":"S. H. Ku","affiliation":["Macronix International Company, Ltd., Hsinchu, Taiwan"],"firstName":"S. H.","lastName":"Ku","id":"37302469200"},{"name":"Lenvis Liu","affiliation":["Macronix International Company, Ltd., Hsinchu, Taiwan"],"firstName":"Lenvis","lastName":"Liu","id":"37835990300"},{"name":"S. W. Hwang","affiliation":["Macronix International Company, Ltd., Hsinchu, Taiwan"],"firstName":"S. W.","lastName":"Hwang","id":"37086089199"},{"name":"Tao-Cheng Lu","affiliation":["Macronix International Company, Ltd., Hsinchu, Taiwan"],"firstName":"Tao-Cheng","lastName":"Lu","id":"37277751000"},{"name":"Kuang-Chao Chen","affiliation":["Macronix International Company, Ltd., Hsinchu, Taiwan"],"firstName":"Kuang-Chao","lastName":"Chen","orcid":"0000-0002-7715-808X","id":"37291294200"},{"name":"Tseung-Yuen Tseng","affiliation":["Department of Electronics Engineering and Institute of Electronics, National Chiao Tung University, Hsinchu, Taiwan"],"firstName":"Tseung-Yuen","lastName":"Tseng","orcid":"0000-0003-1158-5289","id":"37287702900"},{"name":"Chih-Yuan Lu","affiliation":["Macronix International Company, Ltd., Hsinchu, Taiwan"],"firstName":"Chih-Yuan","lastName":"Lu","id":"37280494800"}],"issn":[{"format":"Print ISSN","value":"0018-9383"},{"format":"Electronic ISSN","value":"1557-9646"}],"articleNumber":"8666060","mediaPath":"/mediastore/IEEE/content/media/16/8668593/8666060","dbTime":"2 ms","metrics":{"wosCitationCount":0,"citationCountPaper":16,"citationCountPatent":0,"totalDownloads":2262},"purchaseOptions":{"showOtherFormatPricingTab":false,"showPdfFormatPricingTab":true,"pdfPricingInfoAvailable":false,"otherPricingInfoAvailable":false,"mandatoryBundle":false,"optionalBundle":false,"displayTextWhenPdfPricingNotAvailable":"The purchase and pricing options for this item are unavailable. Select items are only available as part of a subscription package. You may try again later or <a href='https://ieeexplore.ieee.org/xpl/contact' target='_blank'>contact us</a> for more information.","displayTextWhenOtherFormatPricingNotAvailable":"The purchase and pricing options for this item are unavailable. Select items are only available as part of a subscription package. You may try again later or <a href='https://ieeexplore.ieee.org/xpl/contact' target='_blank'>contact us</a> for more information."},"getProgramTermsAccepted":false,"sections":{"abstract":"true","authors":"true","disclaimer":"false","figures":"true","multimedia":"false","references":"true","citedby":"true","keywords":"true","definitions":"false","algorithm":"false","dataset":"false","cadmore":"false","footnotes":"false","relatedContent":"false","metrics":"true"},"abstract":"Transient cell current caused by the trapping/detrapping of grain boundary traps in the polycrystalline silicon (poly-Si) channel of a 3-D NAND cell string is comprehensively studied in this paper. This transient has a time constant of 10 μs or longer and is strongly dependent on the bias history. It is also affected by the trap distribution as revealed by TCAD simulations. Sensing offset between program verify and read results in “pseudo” charge loss/gain that reduces the sensing margin. The posttreatment of the poly-Si channel is suggested to mitigate this effect.","pdfPath":"/iel7/16/8668593/08666060.pdf","publicationDate":"April 2019","publicationYear":"2019","pdfUrl":"/stamp/stamp.jsp?tp=&arnumber=8666060","formulaStrippedArticleTitle":"Grain Boundary Trap-Induced Current Transient in a 3-D NAND Flash Cell String","startPage":"1734","endPage":"1740","displayPublicationTitle":"IEEE Transactions on Electron Devices","publicationTitle":"IEEE Transactions on Electron Devices","doiLink":"https://doi.org/10.1109/TED.2019.2900736","articleCopyRight":"2019 IEEE","rightsLink":"http://s100.copyright.com/AppDispatchServlet?publisherName=ieee&publication=16&title=Grain+Boundary+Trap-Induced+Current+Transient+in+a+3-D+NAND+Flash+Cell+String&isbn=&publicationDate=April+2019&author=Wei-Liang+Lin&ContentID=10.1109/TED.2019.2900736&orderBeanReset=true&startPage=1734&endPage=1740&volumeNum=66&issueNum=4","allowComments":false,"issueLink":"/xpl/tocresult.jsp?isnumber=8668593&punumber=16","authorNames":"Wei-Liang Lin;Wen-Jer Tsai;C. C. Cheng;S. H. Ku;Lenvis Liu;S. W. Hwang;Tao-Cheng Lu;Kuang-Chao Chen;Tseung-Yuen Tseng;Chih-Yuan Lu","keywords":[{"type":"IEEE Keywords","kwd":["Transient analysis","Logic gates","Electron traps","Silicon","Sensors","Grain boundaries","Steady-state"]},{"type":"Index Terms","kwd":["Grain Boundaries","NAND Flash","Time Constant","TCAD Simulation","Steady State","Band Gap","Hysteresis","Grain Size","Surface Potential","Ramp Rate","Steady-state Value","Transient Behavior","Charge Injection","Drain Current","Band Bending","Flash Memory","Source Measure Unit","Hole Accumulation","Capture Cross Section","quasi-Fermi Level"]},{"type":"Author Keywords","kwd":["3-D NAND flash","cell current/threshold voltage instability","gate-all-around (GAA)","grain boundary trap (GBT)","nonvolatile memory","polycrystalline silicon channel","program verify (PV)","transient","trapping/detrapping"]}],"displayPublicationDate":"12 March 2019","dateOfInsertion":"12 March 2019","pubLink":"/xpl/RecentIssue.jsp?punumber=16","isGetAddressInfoCaptured":false,"isMarketingOptIn":false,"pubTopics":[{"name":"Components, Circuits, Devices and Systems"},{"name":"Engineered Materials, Dielectrics and Plasmas"}],"publisher":"IEEE","displayDocTitle":"Grain Boundary Trap-Induced Current Transient in a 3-D NAND Flash Cell String","volume":"66","isConference":false,"isPromo":false,"isSpringer":false,"isDynamicHtml":true,"isJournal":true,"isFreeDocument":false,"isStandard":false,"isOnlineOnly":false,"isChapter":false,"xploreDocumentType":"Journals & Magazine","isTutorial":false,"isBookWithoutChapters":false,"isBook":false,"issue":"4","isProduct":false,"isOpenAccess":false,"isEphemera":false,"isEarlyAccess":false,"isNow":false,"isLatestStandard":false,"hasStandardVersions":false,"htmlLink":"/document/8666060/","isCustomDenial":false,"isDegruyter":false,"isOUP":false,"isSAE":false,"isSMPTE":false,"htmlAbstractLink":"/document/8666060/","persistentLink":"https://xplorestaging.ieee.org/servlet/opac?punumber=16","isGiveaway":false,"isTranslation":false,"startPage":"1734","articleCopyRight":"2019 IEEE","openAccessFlag":"F","insertDate":"12 March 2019","ephemeraFlag":"false","title":"Grain Boundary Trap-Induced Current Transient in a 3-D NAND Flash Cell String","html_flag":"false","ml_html_flag":"true","sourcePdf":"ted-lin-2900736-x.pdf","displayPublicationDate":"12 March 2019","mlTime":"PT0.902698S","xplore-pub-id":"16","pdfPath":"/iel7/16/8668593/08666060.pdf","sponsors":[{"name":"IEEE Electron Devices Society","url":"http://eds.ieee.org/"}],"isNumber":"8668593","rightsLinkFlag":"1","contentType":"periodicals","publicationDate":"April 2019","publicationNumber":"16","citationCount":"16","xplore-issue":"8668593","issue":"4","articleId":"8666060","publicationTitle":"IEEE Transactions on Electron Devices","sections":{"abstract":"true","authors":"true","disclaimer":"false","figures":"true","multimedia":"false","references":"true","citedby":"true","keywords":"true","definitions":"false","algorithm":"false","dataset":"false","cadmore":"false","footnotes":"false","relatedContent":"false","metrics":"true"},"volume":"66","contentTypeDisplay":"Journals","referenceCount":29,"publicationYear":"2019","subType":"IEEE Transaction","_value":"IEEE","lastupdate":"2026-05-09","mediaPath":"/mediastore/IEEE/content/media/16/8668593/8666060","endPage":"1740","displayPublicationTitle":"IEEE Transactions on Electron Devices","doi":"10.1109/TED.2019.2900736"};








</script>



<div class="ng2-app">
	
	
		<!-- <xpl-searchbar show-count="false"></xpl-searchbar> -->
	
	<div class="global-content-wrapper">
		<xpl-root>
			<div class="Spinner"></div>
		</xpl-root>
	</div>
	
	<!-- START: Angular 2+ Migration: Due to Angualr2+ migration AngualrJs router place holder commented -->
<!-- 	<div ng-show="stateIsLoading" class="Spinner"></div>
	<div ui-view class="{{stateIsLoading ? 'loading': ''}}"
		autoscroll="false"></div>
 -->	<!-- END: Angular 2+ Migration-->
</div>

						




<section id="xploreFooter">
	
	<div class="Footer stats-footer hide-mobile" data-analytics_identifier="footer">
		<div class="pure-g Footer-sections">
			<div class="pure-u-1-4">
				<h3 class="Footer-header">IEEE Account</h3>
				<ul class="Footer-list">
					<li><a href="https://www.ieee.org/profile/changeusrpwd/showChangeUsrPwdPage.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore">Change Username/Password</a></li>
					<li><a href="https://www.ieee.org/profile/address/getAddrInfoPage.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore">Update Address</a></li>
				</ul>
			</div>
			<div class="pure-u-1-4">
				<h3 class="Footer-header">Purchase Details</h3>
				<ul class="Footer-list">
					<li><a href="https://www.ieee.org/profile/payment/showPaymentHome.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore">Payment Options</a></li>
					<li><a href="https://www.ieee.org/profile/vieworder/showOrderHistory.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore">Order History</a></li>
					<li><a href="/articleSale/purchaseHistory.jsp">View Purchased Documents</a></li>
				</ul>
			</div>
			<div class="pure-u-1-4">
				<h3 class="Footer-header">Profile Information</h3>
				<ul class="Footer-list">
					<li><a href="https://www.ieee.org/ieee-privacyportal/app/ibp?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore">Communications Preferences</a></li>
					<li><a href="https://www.ieee.org/profile/profedu/getProfEduInformation.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore">Profession and Education</a></li>
					<li><a href="https://www.ieee.org/profile/tips/getTipsInfo.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore">Technical Interests</a></li>
				</ul>
			</div>
			<div class="pure-u-1-4">
				<h3 class="Footer-header">Need Help?</h3>
				<ul class="Footer-list">
					<li><strong>US &amp; Canada:</strong> +1 800 678 4333</li>
					<li><strong>Worldwide: </strong> +1 732 981 0060<br>
					</li>
					<li><a href="/xpl/contact">Contact &amp; Support</a></li>
				</ul>
			</div>
		</div>
		<div class="row">
			<div class="col-12 Footer-bottom" data-analytics_identifier="footer_bottom">
				<div class="Footer-bottom-inner-div row">
					<div class="col">
						<ul class="Menu Menu--horizontal Menu--dividers u-mb-1">
							<li class="Menu-item"><a href="/Xplorehelp/overview-of-ieee-xplore/about-ieee-xplore">About IEEE <em>Xplore</em></a></li>
							<li class="Menu-item"><a href="/xpl/contact">Contact Us</a></li>
							<li class="Menu-item"><a href="/Xplorehelp" target="blank">Help</a></li>
							<li class="Menu-item"><a href="/Xplorehelp/overview-of-ieee-xplore/accessibility-statement" target="blank">Accessibility</a></li> 
							<li class="Menu-item"><a href="/Xplorehelp/overview-of-ieee-xplore/terms-of-use" target="_blank">Terms of Use</a></li>
							<li class="Menu-item"><a href="http://www.ieee.org/web/aboutus/whatis/policies/p9-26.html">Nondiscrimination Policy</a></li>
							<li class="Menu-item"><a href="/xpl/sitemap.jsp">Sitemap</a></li>
							<li class="Menu-item"><a href="http://www.ieee.org/about/help/security_privacy.html" target="blank">Privacy &amp; Opting Out of Cookies</a></li>
						</ul>
						<p class="Footer-bottom-terms">
							A not-for-profit organization, IEEE is the world's largest technical professional organization dedicated to advancing technology for the benefit of humanity.<br>&copy; Copyright 2026 IEEE - All rights reserved. Use of this web site signifies your agreement to the terms and conditions.
						</p>
					</div>

					<div><i class="logo-ieee-white"></i></div>
				</div>
				
			</div>
		</div>
	</div>

	
	
</section>

						<!-- BEGIN: tealium in v2/common/template.jsp. We need to include tealiumAnalytics.js here since Angular 2+ app load if you load after commnon.js then tealium value will not be available in angular 2+ app  -->
						






		<!-- BEGIN: TealiumAnalytics.jsp -->
		
		
		
		
		
		
		
		
		
		
		
		
			
				
			
			
			
			
		
		
		
		
		
		

			<script type ="text/javascript">
 				// tealium config vars
				var TEALIUM_CONFIG_TAGGING_ENABLED = true;		
				var TEALIUM_CONFIG_CDN_URL = '//tags.tiqcdn.com/utag/';
				var TEALIUM_CONFIG_ACCOUNT_PROFILE_ENV = 'ieeexplore/main/staging';
				
				// tealium utag_data values for user 
				var TEALIUM_userType = 'Anonymous';
				var TEALIUM_userInstitutionId = '';
				var TEALIUM_userId = '';
				var TEALIUM_user_third_party = '';
				
				var TEALIUM_products = '';
			</script>

			<script type="text/javascript" src="/assets/dist/js/analytics/tealiumTagsData.js?cv=20240710_830000"></script>
			<script type="text/javascript" src="/assets/dist/js/analytics/tealiumAnalytics.js?cv=20240710_830000"></script>


		
 		
		<!-- END: TealiumAnalytics.jsp -->
			 

						<!-- END: tealium in v2/common/template.jsp -->
						






<script type="text/javascript" src="/xploreAssets/MathJax-274/MathJax.js?config=default"></script>















<link rel="stylesheet" href="/assets/css/ie7Sniffer.css?cv=20240710_830000">
<script type="text/javascript" src="/assets/vendor/js-cookie/src/js.cookie.js?cv=20240710_830000"></script>



	<script type="text/javascript" src="/assets/vendor/fingerprintjs2/fingerprint2.js?cv=20240710_830000"></script>
	<script type="text/javascript" src="/assets/dist/js/fingerprint/fingerprint.js?cv=20240710_830000"></script>


<!-- START OF Angular bundle assets -->
<script type="text/javascript" src='/assets/dist/ng-new/runtime.js?cv=20240710_830000' defer charset="utf-8"></script>
<script type="text/javascript" src='/assets/dist/ng-new/polyfills.js?cv=20240710_830000' defer charset="utf-8"></script>

<script type="text/javascript" src='/assets/dist/ng-new/main.js?cv=20240710_830000' defer charset="utf-8"></script>
<!-- END OF Angular bundle assets -->

<!-- Usabilla Combicode for IEEE-->
<!-- Begin Usabilla for Websites embed code -->
<script type="text/javascript">/*{literal}<![CDATA[*/window.lightningjs||function(c){function g(b,d){d&&(d+=(/\?/.test(d)?"&":"?")+"lv=1");c[b]||function(){var i=window,h=document,j=b,g=h.location.protocol,l="load",k=0;(function(){function b(){a.P(l);a.w=1;c[j]("_load")}c[j]=function(){function m(){m.id=e;return c[j].apply(m,arguments)}var b,e=++k;b=this&&this!=i?this.id||0:0;(a.s=a.s||[]).push([e,b,arguments]);m.then=function(b,c,h){var d=a.fh[e]=a.fh[e]||[],j=a.eh[e]=a.eh[e]||[],f=a.ph[e]=a.ph[e]||[];b&&d.push(b);c&&j.push(c);h&&f.push(h);return m};return m};var a=c[j]._={};a.fh={};a.eh={};a.ph={};a.l=d?d.replace(/^\/\//,(g=="https:"?g:"http:")+"//"):d;a.p={0:+new Date};a.P=function(b){a.p[b]=new Date-a.p[0]};a.w&&b();i.addEventListener?i.addEventListener(l,b,!1):i.attachEvent("on"+l,b);var q=function(){function b(){return["<head></head><",c,' onload="var d=',n,";d.getElementsByTagName('head')[0].",d,"(d.",g,"('script')).",i,"='",a.l,"'\"></",c,">"].join("")}var c="body",e=h[c];if(!e)return setTimeout(q,100);a.P(1);var d="appendChild",g="createElement",i="src",k=h[g]("div"),l=k[d](h[g]("div")),f=h[g]("iframe"),n="document",p;k.style.display="none";e.insertBefore(k,e.firstChild).id=o+"-"+j;f.frameBorder="0";f.id=o+"-frame-"+j;/MSIE[ ]+6/.test(navigator.userAgent)&&(f[i]="javascript:false");f.allowTransparency="true";l[d](f);try{f.contentWindow[n].open()}catch(s){a.domain=h.domain,p="javascript:var d="+n+".open();d.domain='"+h.domain+"';",f[i]=p+"void(0);"}try{var r=f.contentWindow[n];r.write(b());r.close()}catch(t) { f[i]=p+'d.write("'+b().replace(/"/g,String.fromCharCode(92)+'"')+'");d.close();'}a.P(2)}; a.l&&setTimeout(q,0)})()}();c[b].lv="1";return c[b]}var o="lightningjs",k=window[o]=g(o);k.require=g;k.modules=c}({}); if(!navigator.userAgent.match(/Android|BlackBerry|BB10|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {window.usabilla_live = lightningjs.require("usabilla_live", "//w.usabilla.com/e9930a118e08.js"); } else {window.usabilla_live = lightningjs.require("usabilla_live", "//w.usabilla.com/118ca38ae742.js"); }/*]]>{/literal}*/</script>
<!-- end usabilla live embed code -->










	







<div style="width: 1263px;" id="popup_overlay"></div>

<g:compress>








		
		
			
				
					
					
								<script type="text/javascript" src='/assets/vendor/modernizr/modernizr.js?cv=20240710_830000' charset="utf-8"></script>
					
								
			
				
					
						








 

<script>
	var $j = jQuery.noConflict();
	var j$ = jQuery.noConflict();
	var membershipIncomplete;
    var IS_INDIVIDUAL_USER=false;

	var searchPropertiesParamQueryText = 'queryText';
	var searchPropertiesParamNewSearch = 'newsearch';
	var searchPropertiesParamMatchBoolean = 'matchBoolean';
	var searchPropertiesParamSearchWithin = 'searchWithin';
	var searchInterfaceArticleIndexTermReference = 'Search_Index_Terms';
	var searchPropertiesParamRecordsPerPage = 'rowsPerPage';
	var searchPropertiesParamPageNumber = 'pageNumber';
	var searchPropertiesParamRemoveRefinement = 'removeRefinement';	
	var searchPropertiesParamSearchField = 'searchField';
	var searchPropertiesParamArticleNumber = 'arnumber';
	
	var authorsGetDisplay = 'Authors';
	var authorsFirstNameProperty = 'First Name';
	var authorsLastNameProperty = 'Last Name';
	var authorsMiddleNameProperty = 'Middle Name';
	var pubTitleDispNameProperty = 'Publication Title';
	var volumeDispNameProperty = 'Volume';
	var issueDispNameProperty = 'Issue';
	var startPageDispNameProperty = 'Start Page';
	var endPageDispNameProperty = 'Start Page';

	var searchIcsTermProperty = 'Standards ICS Terms';
	var SearchMapperParamSearchField = 'searchField';
	
	var SearchMapperParamNewSearch = 'newsearch';
	var SearchMapperParamArticleNumber = 'arnumber';	
		
	
	
	var NTPT_IMAGE_LOCATION = '';
	var XPLORE_SSL_HOST = 'https://xplorestaging.ieee.org';	
	
	var SSL_YES_NO = 'yes';
	if (SSL_YES_NO.toUpperCase() == "NO"){
		var XPLORE_SSL_YES_NO = false;
	}else{
		var XPLORE_SSL_YES_NO = true;
	}
	var WEBSERVICES_SSL_YES_NO = 'yes';
	if (WEBSERVICES_SSL_YES_NO.toUpperCase() == "NO"){
		var XPLORE_WEBSERV_YES_NO = false;
	}else{
		var XPLORE_WEBSERV_YES_NO = true;
	}
	
	var AUTHOR_PROFILE = 'ON';
	if (AUTHOR_PROFILE.toUpperCase() == "OFF"){
		var AUTHOR_PROFILE_ENABLED = false;
	}else{
		var AUTHOR_PROFILE_ENABLED = true;
	}

	var IMAGE_SEARCH_FLAG = 'ON';
	if (IMAGE_SEARCH_FLAG.toUpperCase() == "ON"){
		var IMAGE_SEARCH_ENABLED = true;
	} else {
		var IMAGE_SEARCH_ENABLED = false;
	}

	var CFAP_ENABLED = 'ON';
	if (CFAP_ENABLED.toUpperCase() == "ON"){
		var CFAP_ENABLED = true;
	} else {
		var CFAP_ENABLED = false;
	}	
	
	var CFAP_FEEDBACK_SAVED_ENABLED = 'ON';
	if (CFAP_FEEDBACK_SAVED_ENABLED.toUpperCase() == "ON"){
		var CFAP_FEEDBACK_SAVED_ENABLED = true;
	} else {
		var CFAP_FEEDBACK_SAVED_ENABLED = false;
	}	
	
	var FREE_ARTICLE_PROMO_FLAG = 'OFF';	
	
	if (FREE_ARTICLE_PROMO_FLAG.toUpperCase() == "ON"){
		var FREE_ARTICLE_PROMO_FLAG = true;
	} else {
		var FREE_ARTICLE_PROMO_FLAG = false;
	}
	
	var ILN_ENABLED = true;
	var SEAMLESS_ENABLED=false;
	var MANAGE_AUTHOR=true;
	var AUTHOR_CLAIM_URL='https://xplorestaging.ieee.org';
	
	
	var IBP_MEMBEER_SIGNIN_TIME_WAIT_IN_MILLIES = '2800';
	var ASSETS_RELATIVE_PATH = '/assets'; // NOTE: AngularJS code relies on this
	var ASSETS_RELATIVE_PATH_NO_SERVER = '/assets';
	var ASSETS_VERSION = '20240710_830000'; // NOTE: AngularJS code relies on this
	var IBP_WS_ASSETS='https://www.ieee.org';
	var IBP_WS_ENABLED_FLAG = false;
	var ENTERPRISE_CART_URL = 'https://www.ieee.org/cart/public/myCart/page.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE%20Xplore';
	var IEEE_USER_INFO_COOKIE = 'ieeeUserInfoCookie';
	
	var ACC_MGMT_NEW = false;
	if (! XPLORE_WEBSERV_YES_NO) {
		var ACC_MGMT_NEW = 'false';
	}
	var ACC_MGMT_CREATE_URL = 'https://www.ieee.org/profile/public/createwebaccount/showCreateAccount.html?ShowMGAMarkeatbilityOptIn=true&sourceCode=xplore&car=IEEE-Xplore&autoSignin=Y';
	var ACC_MGMT_FORGOT_PASSWD_URL = 'https://www.ieee.org/profile/public/forgotpassword/forgotUsernamePassword.html?sourceCode=xplore';

	var SPECIAL_CHARACTER_MAPS = '&:.AND.,=:.EQ.,+:.PLS.,#:.HSH.';
	var SPECIAL_CHARACTERS = new Array();
	var SPECIAL_CHARACTER_REPLACEMENTS = new Array();
	var characterMaps = SPECIAL_CHARACTER_MAPS.split(",");
	for (var i = 0; i < characterMaps.length; i++) {
		parts = characterMaps[i].split(":");
		SPECIAL_CHARACTERS[i] = parts[0];
		SPECIAL_CHARACTER_REPLACEMENTS[i] = parts[1];
	}

	var MAX_WILDCARDS = '10';
	var MAX_SEARCH_TERMS = '25';
	var ALL_SEARCH_FIELDS = 'Search_Index_Terms:Index Terms,Search_All_Text:Full Text & Metadata,Search_All:All Metadata,fullText:Full Text Only,Search_Knowledge_Synthesis:Knowledge Synthesis,Search_Publication_Title:Search Publication Title,Search_Related_Terms:Search Related Terms,Search_Authors:Author Name,Search_Standard_Ics_Title:ICE Terms,promoTopic:Custom Search,id:Article Number,moduleNumber:Module Number,partNum:Part Num,issn:ISSN,isbn:ISBN,eisbn:EISBN,issueId:IS Number,pubIssueId:Pub Issue Id,accessionNumber:Accession Number,copyrightHolder:Copyright Holder,copyrightYear:Copyright Year,license:License,documentAbstract:Abstract,publicationId:Publication Number,parentPublicationId:Parent Publication Number,parentId:Parent Id,titleHistoryId:Title History Id,standardArticleId:Standard Article Id,title:Document Title,parentTitle:Parent Publication Title,parentDisplayTitle:Parent Display Title,publicationTitle:Publication Title,publicationDisplayTitle:Publication Display Title,volume:Volume,issue:Issue,paddedIssueNumber:Padded Issue Number,part:Part,startPage:Start Page,endPage:End Page,filePath:File Path,publicationDate:Publication Date,PublicationYear:Publication Year,onlineDate:Online Date,month:Month,Author:Author Pref Names,authorNormNames:Author Norm Names,author:Authors,authorIds:Author Ids,firstName:First Name,middleName:Middle Name,lastName:Last Name,authorAffiliations:Author Affiliations,authorBio:Author Bio,authorImg:Author Img,referenceCount:Reference Count,citationCount:Citation Count,downloadCount:Download Count,patentCount:Patent Count,multimediaFlag:Multimedia Flag,biomedicalEngFlag:Biomedical Eng Flag,nonIeee:Non IEEE,stdsProductNumber:STDS Product Number,bmsProductNumber:Bms Product Number,status:Status,doi:DOI,programmingLanguage:Programming Language,articleDoi:Article DOI,publicationDoi:Publication DOI,pdfPath:Pdf Path,pdfSize:Pdf Size,contentSubtype:Content Subtype,Publisher:Publisher,publisherName:Publisher Name,inspecControlledTerms:INSPEC Controlled Terms,ieeeTerms:IEEE Terms,unsiloTerms:Unsilo Terms,authorTerms:Author Keywords,maiTerms:MAI Terms,meshTerms:Mesh_Terms,pacsTerms:PACS Terms,insertDate:Insert Date,ConferenceLocation:Conference Location,indexContent:Index Content,coden:CODEN,documentText:Document Text,standardNumber:Standard Number,preprintFlag:Preprint Flag,rapidPostFlag:Rapid Post Flag,lastUpdate:Last Update,newFlag:New Flag,openAccessFlag:Open Access Flag,publicationOpenAccess:Publication Open Access,promoFlag:Promo Flag,pubmedId:Pubmed Id,duration:Duration,society:Society,conference:Conference,ConferenceCountry:ConferenceCountry,conferenceStartDate:Conference Start Date,conferenceEndDate:Conference End Date,societyUrl:Society URL,idSubject:Id Subject,bookNumber:Book Number,pages:Pages,editionNumber:Edition Number,sequence:Sequence,relatedInfoType:Related Info Type,relatedInfo:Related Info,formatIsbn:Format ISBN,meetingDate:Meeting Date,courseLevel:Course level,courseParts:Course Parts,courseId:Course ID,aboutUrl:About Url,additionalUrl:Additional Url,authorsUrl:Authors Url,openAccessUrl:Open Access Url,openAccessFlag:Open Access flag,partnumVendorurlMediatype:Partnum VendorURL MediaType,brandingImageFile:Branding Image File,coverImageFile:Cover Image File,coverImagePath:Cover Image Path,latestIssueCoverImage:Latest Issue Cover Image,frequency:Frequency,fieldOfInterest:Field Of Interest,gParentPublicationNumber:G Parent Publication Number,msUrl:Ms Url,publicationRelationship:Relationship,societyImage:Society Image,visitUrl:Visit Url,visitWebsite:Visit Website,startYear:Start Year,publicationInactive:Publication Inactive,recordType:Record Type,picCodeDescription:Pic Code Description,picCode:Pic Code,sponsors:Sponsors,sponsoringOrgs:Sponsoring Orgs,issueNotes:Notes,conferenceDate:Conference Date,publicationContact:Publication Contact,isbuyable:isBuyable,standardRelationships:Standard Relationships,unavailableForSale:Unavailable for Sale,availableForSale:Available for Sale,standardFamily:Standard Family,standardGroup:Standard Group,productUrl:Product Url,isbnMediatype:ISBN MediaType,htmlFlag:Html Flag,rightslinkFlag:Rightslink Flag,pageCount:Page Count,name:Name,tableOfContents:Table of Contents,timeStamp:Time Stamp,subTitle:Sub Title,relatedItem:Related Item,referenceMaterial:Reference Material,latestIssueTime:Latest Issue Time,startYear:First Published Year,insertDate:Search Latest Date,pbdFlag:Pbd Flag,lmsUrl:Lms Url,currentVolume:Current Volume,graphicalFile:Graphical File,graphicalCoverImage:Graphical Cover Image,graphicalSummary:Graphical Summary,graphicalType:Graphical Type,graphicalAbstractFile:Graphical Abstract File,graphicalAbstractImage:Graphical Abstract Image,graphicalAbstractType:Graphical Abstract Type,graphicalAbstractSummary:Graphical Abstract Summary,authorNativeNames:Native Name,externalId:Article Page Number,standardBundles:Standard Bundles,standardBundleParts:Standard Bundle Parts,virtualTitle:Virtual Title,seriesName:Series Name,seriesId:Series Id,mlHtmlFlag:ML Html flag,promoDates:Promo Dates,promoStartDate:Promo Start Date,promoEndDate:Promo End Date,issueCompleteFlag:Issue Complete Flag,scope:Scope,purpose:Purpose,standardFamilyTitle:Standard Family Title,thumbnailImg:Thumbnail Img,supplementFile:Supplement File,courseFile:Course File,supplement:Supplement,courseAuthor:Course Author,pdhs:Pdhs,ceus:Ceus,courseFirstFrame:FirstFrame Img,idSubTopic:Id Sub Topic,certificateUrl:Certificate Url,standardRoot:Standard Root,icsTerms:Standards ICS Terms,impactStatement:Impact Statement,affirmedDate:Affirmed Date,sourcePdf:Source Pdf,orcid:Author ORCID,algorithmFlag:Algorithm Flag,fundingAgency:Funding Agency,funder:Funder,pricingKey:Map Pricing Key,publicationRollup:Rollup Key,collection:Collection,previewImage:Preview Image,regularDate:Regular Date,ContentType:Content Type,ringgoldIds:Ringgold ID,figure:Figure,imageCaption:Image Caption,mediaPath:Media Path,publicationVolumeOnly:Publication Volume Only,standardIsLatest:Standard Is Latest,standardHasVersions:Standard Has Versions,publicationDetails:Publication Details,keywords:Keywords,Search_All:All Metadata,Search_All_Text:Full Text & Metadata,fullText:Full Text Only,acpFilter:ACP Filter,TypeAheadTerms:Type Ahead Terms,ContentType:Content Type,Author:Author,Affiliation:Affiliation,Topic:Topic,PublicationTitle:Publication Title,PublicationYear:Year,Publisher:Publisher,ConferenceCountry:Conference Country,ConferenceLocation:Conference Location,StandardStatus:Standard Status,ConferenceYear:Conference Year,PublicationPackage:Subscribed Content,StandardPackage:Standard Package,ReadingRoom:Reading Room,StandardTitle:Standard Title,StdDictionaryTerms:Standards Dictionary Terms,TitleRange:Publication Range,StandardRange:Standard Range,RecordType:Record Type,MediaType:Media Type,BookType:Book Type,CourseType:Course Type,PublicationStandardRange:Publication Standard Range,PerpetualYear:Perpetual Year,OpacTitleRange:Opac Title Range,BookSeries:Book Series,SubjectCategory:Subject Category,Sessions:Sessions,TypeAheadPublication:Type Ahead Publication,SubTopic:Sub Topic,CourseDuration:Course Duration,CourseLevel:Course Level,StandardType:Standard Type,StandardSubtype:Standard SubType,StandardModifier:Standard Modifier,IcsTerms1:Ics Terms 1,IcsTerms2:Ics Terms 2,IcsTerms3:Ics Terms 3,SupplementalItem:Supplemental Items,CourseDuration:Course Duration,SpecialSection:Topics,SocietySection:Society Sections,PublicationTopics:Publication Topics,Keywords:Keywords,ImageType:Image Type';
	var SEARCH_FIELD_REFERENCES = new Array();
	var SEARCH_FIELD_DISPLAYS = new Array();
	var searchFields = ALL_SEARCH_FIELDS.split(",");
	for (var j = 0; j < searchFields.length; j++) {
		parts = searchFields[j].split(":");
		SEARCH_FIELD_REFERENCES[j] = parts[0];
		SEARCH_FIELD_DISPLAYS[j] = parts[1];
	}
	

	var refSite='https://xplorestaging.ieee.org';
	var refSiteName="IEEE Xplore";
	var applicationName = 'Xplore';
	var MC_OPERATION_DELAY_TIMEOUT='5000';
	var MC_ADDING_DELAY_MSG='Please wait.The selected item(s) is being added to the cart.';
	var MC_TIMEOUT='60000';
	var MC_OPERATION_DELAY_MSG_FLAG='true';

	var MEMBER_PROFILE_CHANGE_USERNAMEPASS_LINK = 'https://www.ieee.org/profile/changeusrpwd/showChangeUsrPwdPage.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore';
	var MEMBER_MY_PROFILE ='https://www.ieee.org/profile/myprofile/myprofile.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore';
	var MEMBER_PROFILE_ADDRESSINFO_LINK = 'https://www.ieee.org/profile/address/getAddrInfoPage.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore';
	var MEMBER_PROFILE_PAYMENTINFO_LINK = 'https://www.ieee.org/profile/payment/showPaymentHome.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore';
	var MEMBER_PROFILE_ORDER_HISTORY_LINK = 'https://www.ieee.org/profile/vieworder/showOrderHistory.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore';
	var MEMBER_USER_COMMUNICATION_LINK = 'https://www.ieee.org/ieee-privacyportal/app/ibp?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore';
	var MEMBER_EDUCATIONAL_PROFILE_LINK = 'https://www.ieee.org/profile/profedu/getProfEduInformation.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore';
	var MEMBER_TECHNICAL_INTERESTS_LINK = 'https://www.ieee.org/profile/tips/getTipsInfo.html?refSite=https://xplorestaging.ieee.org&refSiteName=IEEE Xplore';
	var HELPFILE_RELATIVE_PATH = '/Xplorehelp';
	
	//content types
	var CONTENT_TYPE_PARAM = 'contentType';
	var CONTENT_TYPE_BOOKS = 'Books';
	var CONTENT_TYPE_COURSES = 'Courses';
	var CONTENT_TYPE_STANDARDS = 'Standards';
	var CONTENT_TYPE_CONFERENCES = 'Conferences';
	var CONTENT_TYPE_JOURNALS = 'Journals';
	var CONTENT_TYPE_EARLY_ACCESS = 'Early Access Articles';
	
	var USER_COUNTRY = 'United States';
	
	//User Preferences
	var citFormat = "";
	var dlFormat = "";
	var myProjectLimit = 15;
	var myProjectDocumentLimit = 1000;
	var myProjectDocumentTagLimit = 50;
	
	
	//Google ReCaptcha public Key 
	var RECAPTCHA_PUBLIC_KEY = '6Ld6GEUUAAAAALdaAmeGUhZyz1KFFHnd5oCaTW-t';
	var KSEXPORT_ENABLED = 'true';
	if (KSEXPORT_ENABLED.toUpperCase() == "TRUE"){
		var KSEXPORT_ENABLED = true;
	} else {
		var KSEXPORT_ENABLED = false;
	}	

	var seamlessAccessPersistenceUrl = 'https://service.seamlessaccess.org/ps/';
</script>

					
					
								
			
				
					
					
								
			
				
					
					
								<script type="text/javascript" src='/assets/dist/js/history.js?cv=20240710_830000' charset="utf-8"></script>
					
								
			
				
					
					
								<script type="text/javascript" src='/assets/dist/js/master.js?cv=20240710_830000' charset="utf-8"></script>
					
								
			
		
	






<script>

j$('document').ready(function(){
	if (Cookies.get('legacyUserName')) {
		if (IBP_WS_ENABLED_FLAG){
			Modal.refreshLegacyAccountTransition('/xpl/mwLegacyAccountTransition.jsp');
		}
	}
});

</script>

</g:compress>








		
			
					
			
					
			
				
					







<script>
	// Get/Set XPL namespace.
	window.xpl = window.xpl || {};
	
	// Set constants/application properties.
	xpl.properties = { 
			collabratec: { 
					url: 'https://ieee-collabratecqa.ieee.org/app/library'
			}
	};
	
	xpl.properties.details = {
			oqs: ''
	};
</script>
					
			
					
			
					
			
		
		
	





<!-- Removed due to network issues when loading in China -->
<!-- <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-5005a435228f9245" async="async"></script>-->

<!-- Load Mathjax and process the document for Mathjax characters -->


<!-- <script type="text/javascript" src="/xploreAssets/MathJax-274/MathJax.js?config=default"></script> -->


<script defer>
	MathJax.Hub.Queue(["Typeset", MathJax.Hub, document.body]);
</script>



					</div>
				</div>

			
				<script>
					// set $ alias back to jQuery because noConflict mode is used in legacy pages
					window.$ = jQuery;
				</script>
			
		</div><!-- /#LayoutWrapper -->
	</body>
</html>

